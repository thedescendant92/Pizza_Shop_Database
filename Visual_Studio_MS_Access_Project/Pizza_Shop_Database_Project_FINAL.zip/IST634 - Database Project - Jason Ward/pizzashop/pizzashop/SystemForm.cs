﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pizzashop
{
    public partial class SystemForm : Form
    {
        public static SystemForm instance;
        public SystemForm()
        {
            InitializeComponent();
            instance = this;
        }

        private void SystemForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'pizzaShopDatabaseDataSet.Pizza' table. You can move, or remove it, as needed.
            this.pizzaTableAdapter.Fill(this.pizzaShopDatabaseDataSet.Pizza);
            // TODO: This line of code loads data into the 'pizzaShopDatabaseDataSet.Other' table. You can move, or remove it, as needed.
            this.otherTableAdapter.Fill(this.pizzaShopDatabaseDataSet.Other);
            // TODO: This line of code loads data into the 'pizzaShopDatabaseDataSet.Orders' table. You can move, or remove it, as needed.
            this.ordersTableAdapter.Fill(this.pizzaShopDatabaseDataSet.Orders);
            // TODO: This line of code loads data into the 'pizzaShopDatabaseDataSet.Customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.pizzaShopDatabaseDataSet.Customer);
            // TODO: This line of code loads data into the 'pizzaShopDatabaseDataSet.Sys' table. You can move, or remove it, as needed.

            foreach(Control c in Controls)
            {
                if(c is TextBox)
                {
                    c.Text = "";
                }
            }
        }

        private void btnUpdatePrice_Click(object sender, EventArgs e)
        {
            string item = txtItem.Text;

            if (item == "WINGS")
            {
                txtOPrice.Text = "8";
            }
            else if (item == "BREAD")
            {
                txtOPrice.Text = "5";
            }
            else if (item == "COOKIE")
            {
                txtOPrice.Text = "6";
            }
            else if (item == "SUB")
            {
                txtOPrice.Text = "7";
            }
            else
            {
                txtOPrice.Text = "";
            }

        }

        private void btnUpdatePrice1_Click(object sender, EventArgs e)
        {
            string topping = txtTopping.Text;

            if (topping == "1")
            {
                txtOPrice.Text = "10";
            }
            else if (topping == "2")
            {
                txtPPrice.Text = "12";
            }
            else if (topping == "3")
            {
                txtPPrice.Text = "14";
            }
            else if (topping == "4")
            {
                txtPPrice.Text = "16";
            }
            else if (topping == "5")
            {
                txtPPrice.Text = "18";
            }
            else if (topping == "6")
            {
                txtPPrice.Text = "20";
            }
            else
            {
                txtPPrice.Text = "";
            }
        }


        private void btnConfirm_Click(object sender, EventArgs e)
        {
            var iConfirm = MessageBox.Show("Would you like confirm this order?", "J's Pizza", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (iConfirm == DialogResult.Yes)
            {
                ResultsForm form = new ResultsForm();
                form.Show();
                this.Hide();
                customerTableAdapter.Update(this.pizzaShopDatabaseDataSet.Customer);
                ordersTableAdapter.Update(this.pizzaShopDatabaseDataSet.Orders);
                otherTableAdapter.Update(this.pizzaShopDatabaseDataSet.Other); 
                pizzaTableAdapter.Update(this.pizzaShopDatabaseDataSet.Pizza);
                ResultsForm.instance.lab1.Text = txtFirstName.Text;
                ResultsForm.instance.lab2.Text = txtLastName.Text;
                ResultsForm.instance.lab3.Text = txtPhone.Text;
                ResultsForm.instance.lab4.Text = txtAddress.Text;
                ResultsForm.instance.lab5.Text = txtCity.Text;
                ResultsForm.instance.lab6.Text = txtType.Text;
                ResultsForm.instance.lab7.Text = txtItem.Text;
                ResultsForm.instance.lab8.Text = txtOPrice.Text;
                ResultsForm.instance.lab9.Text = txtTopping.Text;
                ResultsForm.instance.lab10.Text = txtPPrice.Text;
                ResultsForm.instance.lab11.Text = dateDateTimePicker.Text;
                ResultsForm.instance.lab12.Text = txtTotality.Text;

            }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            HomeForm home = new HomeForm();
            home.Show();
            this.Hide();
        }

        private void sysBindingNavigator_RefreshItems(object sender, EventArgs e)
        {

        }

        private void txtOPrice_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtOPrice.Text) && !string.IsNullOrEmpty(txtPPrice.Text))
                txtTotality.Text = (Convert.ToInt32(txtOPrice.Text) + Convert.ToInt32(txtPPrice.Text)).ToString();
        }

        private void txtPPrice_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtOPrice.Text) && !string.IsNullOrEmpty(txtPPrice.Text))
                txtTotality.Text = (Convert.ToInt32(txtOPrice.Text) + Convert.ToInt32(txtPPrice.Text)).ToString();
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            MenuForm men = new MenuForm();
            men.Show();
        }
    }
}
