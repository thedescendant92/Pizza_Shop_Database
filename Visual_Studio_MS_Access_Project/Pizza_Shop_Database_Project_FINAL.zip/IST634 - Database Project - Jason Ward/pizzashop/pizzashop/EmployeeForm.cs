﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pizzashop
{
    public partial class EmployeeForm : Form
    {
        public EmployeeForm()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.pizzaShopDatabaseDataSet);

        }

        private void EmployeeForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'pizzaShopDatabaseDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.pizzaShopDatabaseDataSet.Employee);

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            refreshData();
        }
        private void refreshData()
        {
            //Clear Filter
            this.employeeBindingSource.Filter = null;

            this.employeeTableAdapter.Fill(this.pizzaShopDatabaseDataSet.Employee);

            this.txtSearch.Text = "";
            this.txtSearch.Focus();

            this.btnAddNew.Text = "Add new";
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            HomeForm home = new HomeForm();
            home.Show();
            this.Hide();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            bindingNavigatorMovePreviousItem.PerformClick();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            bindingNavigatorMoveNextItem.PerformClick();
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.PerformClick();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var save = MessageBox.Show("Are you sure you would like to save?", "J's Pizza", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (save == DialogResult.Yes)
            {
                employeeBindingNavigatorSaveItem.PerformClick();
                employeeTableAdapter.Update(this.pizzaShopDatabaseDataSet.Employee);
            }
        }

        private void employeeDataGridView_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            e.Cancel = true;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string strFilter = this.txtSearch.Text.Replace("'", "''");

            if (string.IsNullOrEmpty(this.txtSearch.Text))
            {
                refreshData();
            }
            else
            {
                string queryByID = "(Convert([Employee ID], 'System.String') = '" + strFilter.Trim() + "') ";

                string queryByFName = "OR (Convert([First Name], 'System.String') LIKE '%" + strFilter + @"%') "; // % Wildcard

                string queryByLName = "OR (Convert([Last Name], 'System.String') LIKE '%" + strFilter + "%') ";

                string queryByPhone = "OR (Convert([Phone Number], 'System.String') LIKE '%" + strFilter + "%') ";

                string queryByPositionID = "OR (Convert([Position ID], 'System.String') LIKE '%" + strFilter + "%') ";

                StringBuilder joinQuery = new StringBuilder(); // System.Text

                joinQuery.Append(queryByID);
                joinQuery.Append(queryByFName);
                joinQuery.Append(queryByLName);
                joinQuery.Append(queryByPositionID);
                joinQuery.Append(queryByPhone);

                this.employeeBindingSource.Filter = joinQuery.ToString();

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            bindingNavigatorDeleteItem.PerformClick();
        }
    }
}
