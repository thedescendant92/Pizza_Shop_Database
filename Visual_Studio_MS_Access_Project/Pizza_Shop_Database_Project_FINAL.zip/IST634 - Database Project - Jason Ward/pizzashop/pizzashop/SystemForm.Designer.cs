﻿namespace pizzashop
{
    partial class SystemForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label first_NameLabel1;
            System.Windows.Forms.Label last_NameLabel1;
            System.Windows.Forms.Label phone_NumberLabel1;
            System.Windows.Forms.Label addressLabel1;
            System.Windows.Forms.Label cityLabel1;
            System.Windows.Forms.Label order_TypeLabel1;
            System.Windows.Forms.Label dateLabel1;
            System.Windows.Forms.Label itemLabel1;
            System.Windows.Forms.Label priceLabel;
            System.Windows.Forms.Label topping_CountLabel1;
            System.Windows.Forms.Label priceLabel1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SystemForm));
            this.pizzaShopDatabaseDataSet = new pizzashop.PizzaShopDatabaseDataSet();
            this.btnUpdatePrice = new System.Windows.Forms.Button();
            this.btnUpdatePrice1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.customerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtType = new System.Windows.Forms.TextBox();
            this.ordersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.txtItem = new System.Windows.Forms.TextBox();
            this.otherBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtOPrice = new System.Windows.Forms.TextBox();
            this.txtTopping = new System.Windows.Forms.TextBox();
            this.pizzaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtPPrice = new System.Windows.Forms.TextBox();
            this.tableAdapterManager = new pizzashop.PizzaShopDatabaseDataSetTableAdapters.TableAdapterManager();
            this.customerTableAdapter = new pizzashop.PizzaShopDatabaseDataSetTableAdapters.CustomerTableAdapter();
            this.ordersTableAdapter = new pizzashop.PizzaShopDatabaseDataSetTableAdapters.OrdersTableAdapter();
            this.otherTableAdapter = new pizzashop.PizzaShopDatabaseDataSetTableAdapters.OtherTableAdapter();
            this.pizzaTableAdapter = new pizzashop.PizzaShopDatabaseDataSetTableAdapters.PizzaTableAdapter();
            this.txtTotality = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblA = new System.Windows.Forms.Label();
            this.btnMenu = new System.Windows.Forms.Button();
            first_NameLabel1 = new System.Windows.Forms.Label();
            last_NameLabel1 = new System.Windows.Forms.Label();
            phone_NumberLabel1 = new System.Windows.Forms.Label();
            addressLabel1 = new System.Windows.Forms.Label();
            cityLabel1 = new System.Windows.Forms.Label();
            order_TypeLabel1 = new System.Windows.Forms.Label();
            dateLabel1 = new System.Windows.Forms.Label();
            itemLabel1 = new System.Windows.Forms.Label();
            priceLabel = new System.Windows.Forms.Label();
            topping_CountLabel1 = new System.Windows.Forms.Label();
            priceLabel1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pizzaShopDatabaseDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.otherBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pizzaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // first_NameLabel1
            // 
            first_NameLabel1.AutoSize = true;
            first_NameLabel1.Location = new System.Drawing.Point(230, 208);
            first_NameLabel1.Name = "first_NameLabel1";
            first_NameLabel1.Size = new System.Drawing.Size(60, 13);
            first_NameLabel1.TabIndex = 41;
            first_NameLabel1.Text = "First Name:";
            // 
            // last_NameLabel1
            // 
            last_NameLabel1.AutoSize = true;
            last_NameLabel1.Location = new System.Drawing.Point(230, 234);
            last_NameLabel1.Name = "last_NameLabel1";
            last_NameLabel1.Size = new System.Drawing.Size(61, 13);
            last_NameLabel1.TabIndex = 43;
            last_NameLabel1.Text = "Last Name:";
            // 
            // phone_NumberLabel1
            // 
            phone_NumberLabel1.AutoSize = true;
            phone_NumberLabel1.Location = new System.Drawing.Point(230, 260);
            phone_NumberLabel1.Name = "phone_NumberLabel1";
            phone_NumberLabel1.Size = new System.Drawing.Size(81, 13);
            phone_NumberLabel1.TabIndex = 45;
            phone_NumberLabel1.Text = "Phone Number:";
            // 
            // addressLabel1
            // 
            addressLabel1.AutoSize = true;
            addressLabel1.Location = new System.Drawing.Point(230, 286);
            addressLabel1.Name = "addressLabel1";
            addressLabel1.Size = new System.Drawing.Size(48, 13);
            addressLabel1.TabIndex = 47;
            addressLabel1.Text = "Address:";
            // 
            // cityLabel1
            // 
            cityLabel1.AutoSize = true;
            cityLabel1.Location = new System.Drawing.Point(230, 312);
            cityLabel1.Name = "cityLabel1";
            cityLabel1.Size = new System.Drawing.Size(27, 13);
            cityLabel1.TabIndex = 49;
            cityLabel1.Text = "City:";
            // 
            // order_TypeLabel1
            // 
            order_TypeLabel1.AutoSize = true;
            order_TypeLabel1.Location = new System.Drawing.Point(230, 338);
            order_TypeLabel1.Name = "order_TypeLabel1";
            order_TypeLabel1.Size = new System.Drawing.Size(63, 13);
            order_TypeLabel1.TabIndex = 50;
            order_TypeLabel1.Text = "Order Type:";
            // 
            // dateLabel1
            // 
            dateLabel1.AutoSize = true;
            dateLabel1.Location = new System.Drawing.Point(466, 208);
            dateLabel1.Name = "dateLabel1";
            dateLabel1.Size = new System.Drawing.Size(33, 13);
            dateLabel1.TabIndex = 51;
            dateLabel1.Text = "Date:";
            // 
            // itemLabel1
            // 
            itemLabel1.AutoSize = true;
            itemLabel1.Location = new System.Drawing.Point(466, 265);
            itemLabel1.Name = "itemLabel1";
            itemLabel1.Size = new System.Drawing.Size(59, 13);
            itemLabel1.TabIndex = 52;
            itemLabel1.Text = "Other Item:";
            // 
            // priceLabel
            // 
            priceLabel.AutoSize = true;
            priceLabel.Location = new System.Drawing.Point(466, 289);
            priceLabel.Name = "priceLabel";
            priceLabel.Size = new System.Drawing.Size(63, 13);
            priceLabel.TabIndex = 53;
            priceLabel.Text = "Other Price:";
            // 
            // topping_CountLabel1
            // 
            topping_CountLabel1.AutoSize = true;
            topping_CountLabel1.Location = new System.Drawing.Point(466, 315);
            topping_CountLabel1.Name = "topping_CountLabel1";
            topping_CountLabel1.Size = new System.Drawing.Size(80, 13);
            topping_CountLabel1.TabIndex = 54;
            topping_CountLabel1.Text = "Topping Count:";
            // 
            // priceLabel1
            // 
            priceLabel1.AutoSize = true;
            priceLabel1.Location = new System.Drawing.Point(466, 341);
            priceLabel1.Name = "priceLabel1";
            priceLabel1.Size = new System.Drawing.Size(62, 13);
            priceLabel1.TabIndex = 55;
            priceLabel1.Text = "Pizza Price:";
            // 
            // pizzaShopDatabaseDataSet
            // 
            this.pizzaShopDatabaseDataSet.DataSetName = "PizzaShopDatabaseDataSet";
            this.pizzaShopDatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnUpdatePrice
            // 
            this.btnUpdatePrice.Location = new System.Drawing.Point(658, 265);
            this.btnUpdatePrice.Name = "btnUpdatePrice";
            this.btnUpdatePrice.Size = new System.Drawing.Size(131, 34);
            this.btnUpdatePrice.TabIndex = 34;
            this.btnUpdatePrice.Text = "Update Other Price";
            this.btnUpdatePrice.UseVisualStyleBackColor = true;
            this.btnUpdatePrice.Click += new System.EventHandler(this.btnUpdatePrice_Click);
            // 
            // btnUpdatePrice1
            // 
            this.btnUpdatePrice1.Location = new System.Drawing.Point(658, 320);
            this.btnUpdatePrice1.Name = "btnUpdatePrice1";
            this.btnUpdatePrice1.Size = new System.Drawing.Size(131, 34);
            this.btnUpdatePrice1.TabIndex = 35;
            this.btnUpdatePrice1.Text = "Update Pizza Price";
            this.btnUpdatePrice1.UseVisualStyleBackColor = true;
            this.btnUpdatePrice1.Click += new System.EventHandler(this.btnUpdatePrice1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(466, 409);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 37;
            this.label1.Text = "Order Total:";
            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(536, 449);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(131, 34);
            this.btnConfirm.TabIndex = 38;
            this.btnConfirm.Text = "Confirm Order";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnHome
            // 
            this.btnHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.Location = new System.Drawing.Point(847, 502);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(115, 59);
            this.btnHome.TabIndex = 39;
            this.btnHome.Text = "Home";
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // txtFirstName
            // 
            this.txtFirstName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtFirstName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "First Name", true));
            this.txtFirstName.Location = new System.Drawing.Point(317, 205);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(100, 20);
            this.txtFirstName.TabIndex = 42;
            // 
            // customerBindingSource
            // 
            this.customerBindingSource.DataMember = "Customer";
            this.customerBindingSource.DataSource = this.pizzaShopDatabaseDataSet;
            // 
            // txtLastName
            // 
            this.txtLastName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtLastName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "Last Name", true));
            this.txtLastName.Location = new System.Drawing.Point(317, 231);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(100, 20);
            this.txtLastName.TabIndex = 44;
            // 
            // txtPhone
            // 
            this.txtPhone.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPhone.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "Phone Number", true));
            this.txtPhone.Location = new System.Drawing.Point(317, 257);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(100, 20);
            this.txtPhone.TabIndex = 46;
            // 
            // txtAddress
            // 
            this.txtAddress.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtAddress.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "Address", true));
            this.txtAddress.Location = new System.Drawing.Point(317, 283);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(100, 20);
            this.txtAddress.TabIndex = 48;
            // 
            // txtCity
            // 
            this.txtCity.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCity.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerBindingSource, "City", true));
            this.txtCity.Location = new System.Drawing.Point(317, 309);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(100, 20);
            this.txtCity.TabIndex = 50;
            // 
            // txtType
            // 
            this.txtType.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtType.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ordersBindingSource, "Order Type", true));
            this.txtType.Location = new System.Drawing.Point(317, 335);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(100, 20);
            this.txtType.TabIndex = 51;
            // 
            // ordersBindingSource
            // 
            this.ordersBindingSource.DataMember = "Orders";
            this.ordersBindingSource.DataSource = this.pizzaShopDatabaseDataSet;
            // 
            // dateDateTimePicker
            // 
            this.dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.ordersBindingSource, "Date", true));
            this.dateDateTimePicker.Location = new System.Drawing.Point(552, 202);
            this.dateDateTimePicker.MinDate = new System.DateTime(2021, 6, 2, 0, 0, 0, 0);
            this.dateDateTimePicker.Name = "dateDateTimePicker";
            this.dateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dateDateTimePicker.TabIndex = 52;
            // 
            // txtItem
            // 
            this.txtItem.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtItem.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.otherBindingSource, "Item", true));
            this.txtItem.Location = new System.Drawing.Point(552, 260);
            this.txtItem.Name = "txtItem";
            this.txtItem.Size = new System.Drawing.Size(100, 20);
            this.txtItem.TabIndex = 53;
            // 
            // otherBindingSource
            // 
            this.otherBindingSource.DataMember = "Other";
            this.otherBindingSource.DataSource = this.pizzaShopDatabaseDataSet;
            // 
            // txtOPrice
            // 
            this.txtOPrice.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.otherBindingSource, "Price", true));
            this.txtOPrice.Enabled = false;
            this.txtOPrice.Location = new System.Drawing.Point(552, 286);
            this.txtOPrice.Name = "txtOPrice";
            this.txtOPrice.Size = new System.Drawing.Size(100, 20);
            this.txtOPrice.TabIndex = 54;
            this.txtOPrice.TextChanged += new System.EventHandler(this.txtOPrice_TextChanged);
            // 
            // txtTopping
            // 
            this.txtTopping.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pizzaBindingSource, "Topping Count", true));
            this.txtTopping.Location = new System.Drawing.Point(552, 312);
            this.txtTopping.Name = "txtTopping";
            this.txtTopping.Size = new System.Drawing.Size(100, 20);
            this.txtTopping.TabIndex = 55;
            // 
            // pizzaBindingSource
            // 
            this.pizzaBindingSource.DataMember = "Pizza";
            this.pizzaBindingSource.DataSource = this.pizzaShopDatabaseDataSet;
            // 
            // txtPPrice
            // 
            this.txtPPrice.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.pizzaBindingSource, "Price", true));
            this.txtPPrice.Enabled = false;
            this.txtPPrice.Location = new System.Drawing.Point(552, 338);
            this.txtPPrice.Name = "txtPPrice";
            this.txtPPrice.Size = new System.Drawing.Size(100, 20);
            this.txtPPrice.TabIndex = 56;
            this.txtPPrice.TextChanged += new System.EventHandler(this.txtPPrice_TextChanged);
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.CustomerTableAdapter = null;
            this.tableAdapterManager.EmployeeTableAdapter = null;
            this.tableAdapterManager.OrdersTableAdapter = null;
            this.tableAdapterManager.OtherTableAdapter = null;
            this.tableAdapterManager.PizzaTableAdapter = null;
            this.tableAdapterManager.PositionTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = pizzashop.PizzaShopDatabaseDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // customerTableAdapter
            // 
            this.customerTableAdapter.ClearBeforeFill = true;
            // 
            // ordersTableAdapter
            // 
            this.ordersTableAdapter.ClearBeforeFill = true;
            // 
            // otherTableAdapter
            // 
            this.otherTableAdapter.ClearBeforeFill = true;
            // 
            // pizzaTableAdapter
            // 
            this.pizzaTableAdapter.ClearBeforeFill = true;
            // 
            // txtTotality
            // 
            this.txtTotality.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotality.Location = new System.Drawing.Point(552, 406);
            this.txtTotality.Name = "txtTotality";
            this.txtTotality.Size = new System.Drawing.Size(100, 20);
            this.txtTotality.TabIndex = 57;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(221, 377);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(580, 13);
            this.label2.TabIndex = 58;
            this.label2.Text = "---------------------------------------------------------------------------------" +
    "--------------------------------------------------------------------------------" +
    "------------------------------";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(466, 302);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(325, 13);
            this.label3.TabIndex = 59;
            this.label3.Text = "---------------------------------------------------------------------------------" +
    "-------------------------";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(819, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(178, 137);
            this.pictureBox1.TabIndex = 60;
            this.pictureBox1.TabStop = false;
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblA.Location = new System.Drawing.Point(428, 109);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(172, 31);
            this.lblA.TabIndex = 61;
            this.lblA.Text = "Order Sheet";
            // 
            // btnMenu
            // 
            this.btnMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMenu.Location = new System.Drawing.Point(58, 502);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(115, 59);
            this.btnMenu.TabIndex = 62;
            this.btnMenu.Text = "Menu";
            this.btnMenu.UseVisualStyleBackColor = true;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // SystemForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1028, 601);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.lblA);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtTotality);
            this.Controls.Add(priceLabel1);
            this.Controls.Add(this.txtPPrice);
            this.Controls.Add(topping_CountLabel1);
            this.Controls.Add(this.txtTopping);
            this.Controls.Add(priceLabel);
            this.Controls.Add(this.txtOPrice);
            this.Controls.Add(itemLabel1);
            this.Controls.Add(this.txtItem);
            this.Controls.Add(dateLabel1);
            this.Controls.Add(this.dateDateTimePicker);
            this.Controls.Add(order_TypeLabel1);
            this.Controls.Add(this.txtType);
            this.Controls.Add(first_NameLabel1);
            this.Controls.Add(this.txtFirstName);
            this.Controls.Add(last_NameLabel1);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(phone_NumberLabel1);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(addressLabel1);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(cityLabel1);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnUpdatePrice1);
            this.Controls.Add(this.btnUpdatePrice);
            this.Controls.Add(this.label3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "SystemForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "J\'s Pizza - Order Sheet";
            this.Load += new System.EventHandler(this.SystemForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pizzaShopDatabaseDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.otherBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pizzaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PizzaShopDatabaseDataSet pizzaShopDatabaseDataSet;
        private PizzaShopDatabaseDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Button btnUpdatePrice;
        private System.Windows.Forms.Button btnUpdatePrice1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.BindingSource customerBindingSource;
        private PizzaShopDatabaseDataSetTableAdapters.CustomerTableAdapter customerTableAdapter;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.BindingSource ordersBindingSource;
        private PizzaShopDatabaseDataSetTableAdapters.OrdersTableAdapter ordersTableAdapter;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.DateTimePicker dateDateTimePicker;
        private System.Windows.Forms.BindingSource otherBindingSource;
        private PizzaShopDatabaseDataSetTableAdapters.OtherTableAdapter otherTableAdapter;
        private System.Windows.Forms.TextBox txtItem;
        private System.Windows.Forms.TextBox txtOPrice;
        private System.Windows.Forms.BindingSource pizzaBindingSource;
        private PizzaShopDatabaseDataSetTableAdapters.PizzaTableAdapter pizzaTableAdapter;
        private System.Windows.Forms.TextBox txtTopping;
        private System.Windows.Forms.TextBox txtPPrice;
        private System.Windows.Forms.TextBox txtTotality;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Button btnMenu;
    }
}