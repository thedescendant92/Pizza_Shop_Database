﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pizzashop
{
    public partial class CustomerForm : Form
    {
        public CustomerForm()
        {
            InitializeComponent();
        }

        private void customerBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.customerBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.pizzaShopDatabaseDataSet);

        }

        private void CustomerForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'pizzaShopDatabaseDataSet.Customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.pizzaShopDatabaseDataSet.Customer);

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            refreshData();
        }

        private void refreshData()
        {
            //Clear Filter
            this.customerBindingSource.Filter = null;

            this.customerTableAdapter.Fill(this.pizzaShopDatabaseDataSet.Customer);

            this.txtSearch.Text = "";
            this.txtSearch.Focus();

            this.btnAddNew.Text = "Add new";
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            HomeForm home = new HomeForm();
            home.Show();
            this.Hide();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            bindingNavigatorMovePreviousItem.PerformClick();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            bindingNavigatorMoveNextItem.PerformClick();
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.PerformClick();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var save = MessageBox.Show("Are you sure you would like to save?", "J's Pizza", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (save == DialogResult.Yes)
            {
                customerBindingNavigatorSaveItem.PerformClick();
                customerTableAdapter.Update(this.pizzaShopDatabaseDataSet.Customer);
            }
        }

        private void customerDataGridView_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            e.Cancel = true;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            bindingNavigatorDeleteItem.PerformClick();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string strFilter = this.txtSearch.Text.Replace("'", "''");

            if (string.IsNullOrEmpty(this.txtSearch.Text))
            {
                refreshData();
            }
            else
            {
                string queryByID = "(Convert([Customer ID], 'System.String') = '" + strFilter.Trim() + "') ";

                string queryByFName = "OR (Convert([First Name], 'System.String') LIKE '%" + strFilter + @"%') "; // % Wildcard

                string queryByLName = "OR (Convert([Last Name], 'System.String') LIKE '%" + strFilter + "%') ";

                string queryByPhone = "OR (Convert([Phone Number], 'System.String') LIKE '%" + strFilter + "%') ";

                string queryByAddress = "OR (Convert([Address], 'System.String') LIKE '%" + strFilter + "%') ";

                string queryByCity = "OR (Convert([City], 'System.String') LIKE '%" + strFilter + "%') ";


                StringBuilder joinQuery = new StringBuilder(); // System.Text

                joinQuery.Append(queryByID);
                joinQuery.Append(queryByFName);
                joinQuery.Append(queryByLName);
                joinQuery.Append(queryByPhone);
                joinQuery.Append(queryByAddress);
                joinQuery.Append(queryByCity);

                this.customerBindingSource.Filter = joinQuery.ToString();
            }
        }
    }
}
