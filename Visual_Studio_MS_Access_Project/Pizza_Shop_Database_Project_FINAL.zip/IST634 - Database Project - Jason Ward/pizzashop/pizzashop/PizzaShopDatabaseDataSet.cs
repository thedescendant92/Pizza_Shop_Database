﻿namespace pizzashop
{


    partial class PizzaShopDatabaseDataSet
    {
        partial class SysDataTable
        {
        }
    }
}

namespace pizzashop.PizzaShopDatabaseDataSetTableAdapters
{
    partial class SysTableAdapter
    {
    }

    public partial class EmpTableAdapter {
    }
}
