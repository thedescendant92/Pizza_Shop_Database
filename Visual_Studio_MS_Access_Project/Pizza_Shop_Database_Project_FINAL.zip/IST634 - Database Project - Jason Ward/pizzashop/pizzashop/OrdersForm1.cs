﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pizzashop
{
    public partial class OrdersForm1 : Form
    {
        public OrdersForm1()
        {
            InitializeComponent();
        }

        private void ordersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.ordersBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.pizzaShopDatabaseDataSet);

        }

        private void OrdersForm1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'pizzaShopDatabaseDataSet.Orders' table. You can move, or remove it, as needed.
            this.ordersTableAdapter.Fill(this.pizzaShopDatabaseDataSet.Orders);

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            refreshData();
        }
        private void refreshData()
        {
            //Clear Filter
            this.ordersBindingSource.Filter = null;

            this.ordersTableAdapter.Fill(this.pizzaShopDatabaseDataSet.Orders);

            this.txtSearch.Text = "";
            this.txtSearch.Focus();

            this.btnAddNew.Text = "Add new";
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            HomeForm home = new HomeForm();
            home.Show();
            this.Hide();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            bindingNavigatorMovePreviousItem.PerformClick();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            bindingNavigatorMoveNextItem.PerformClick();
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            bindingNavigatorAddNewItem.PerformClick();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var save = MessageBox.Show("Are you sure you would like to save?", "J's Pizza", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (save == DialogResult.Yes)
            {
                ordersBindingNavigatorSaveItem.PerformClick();
                ordersTableAdapter.Update(this.pizzaShopDatabaseDataSet.Orders);
            }
        }

        private void ordersDataGridView_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            e.Cancel = true;
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            bindingNavigatorDeleteItem.PerformClick();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string strFilter = this.txtSearch.Text.Replace("'", "''");

            if (string.IsNullOrEmpty(this.txtSearch.Text))
            {
                refreshData();
            }
            else
            {
                string queryByID = "(Convert([Orders ID], 'System.String') = '" + strFilter.Trim() + "') ";

                string queryByDate = "OR (Convert([Date], 'System.String') LIKE '%" + strFilter + @"%') "; // % Wildcard

                string queryByType = "OR (Convert([Order Type], 'System.String') LIKE '%" + strFilter + "%') ";

                string queryByCusID = "OR (Convert([Customer ID], 'System.String') LIKE '%" + strFilter + "%') ";

                string queryByEmpID = "OR (Convert([Employee ID], 'System.String') LIKE '%" + strFilter + "%') ";

                string queryByPizzID = "OR (Convert([Pizza ID], 'System.String') LIKE '%" + strFilter + "%') ";

                string queryByOthID = "OR (Convert([Other ID], 'System.String') LIKE '%" + strFilter + "%') ";

                StringBuilder joinQuery = new StringBuilder(); // System.Text

                joinQuery.Append(queryByID);
                joinQuery.Append(queryByDate);
                joinQuery.Append(queryByType);
                joinQuery.Append(queryByCusID);
                joinQuery.Append(queryByEmpID);
                joinQuery.Append(queryByPizzID);
                joinQuery.Append(queryByOthID);

                this.ordersBindingSource.Filter = joinQuery.ToString();

            }
        }


    }
}
