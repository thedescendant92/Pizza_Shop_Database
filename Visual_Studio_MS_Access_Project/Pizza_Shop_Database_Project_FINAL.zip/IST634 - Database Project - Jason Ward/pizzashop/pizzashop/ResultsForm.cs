﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pizzashop
{
    public partial class ResultsForm : Form
    {
        public static ResultsForm instance;
        public Label lab1;
        public Label lab2;
        public Label lab3;
        public Label lab4;
        public Label lab5; 
        public Label lab6;
        public Label lab7;
        public Label lab8;
        public Label lab9;
        public Label lab10;
        public Label lab11;
        public Label lab12;


        public ResultsForm()
        {
            InitializeComponent();
            instance = this;
            lab1 = lbl1;
            lab2 = lbl2;
            lab3 = lbl3;
            lab4 = lbl4;
            lab5 = lbl5;
            lab6 = lbl6;
            lab7 = lbl7;
            lab8 = lbl8;
            lab9 = lbl9;
            lab10 = lbl10;
            lab11 = lbl11;
            lab12 = lbl12;

        }

        private void ResultsForm_Load(object sender, EventArgs e)
        {

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            HomeForm home = new HomeForm();
            home.Show();
            this.Hide();
        }

        private void lbl9_Click(object sender, EventArgs e)
        {

        }

        private void lblA_Click(object sender, EventArgs e)
        {

        }
    }
}
